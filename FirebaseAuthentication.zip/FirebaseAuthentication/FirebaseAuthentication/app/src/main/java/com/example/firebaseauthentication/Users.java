package com.example.firebaseauthentication;

public class Users {
    public void setUserId(String userId) {
        UserId = userId;
    }

    private String UserId,FirstName,LastName,Email,Password;

    public Users() {
    }

    public Users(String userId,String firstName, String lastName, String email, String password) {
        UserId=userId;
        FirstName = firstName;
        LastName = lastName;
        Email = email;
        Password = password;
    }

    public String getFirstName() {
        return FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public String getEmail() {
        return Email;
    }

    public String getPassword() {
        return Password;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getUserId() {
        return UserId;
    }
}
